import UIKit

var Num1 = 14
var Num2 = 12
var add = Num1 + Num2
var subtract = Num1 - Num2
var multiply = Num1 * Num2
var divide = Num1 / Num2

print("\(Num1) + \(Num2) = \(add)")
print("\(Num1) - \(Num2) = \(subtract)")
print("\(Num1) * \(Num2) = \(multiply)")
print("\(Num1) / \(Num2) = \(divide)")

