import UIKit

//defines an array
var albums = [Int] ()

albums.append(25)

var soul: [String] = ["All I want is you", "Back to Black","The 20/20 Experience"]

var RAndB: [String] = ["All I want is you", "Back to Black", "ANTI","Chixtape 5","Christmas And Chill"]

RAndB.append("Take Care")

var HipHop: [String] = ["Nothing Was The Same", "Take Care", "The Off Season"]

HipHop.append("Take Care")
HipHop.append("Call Me If You Get Lost")
HipHop.append("Chixtape 5")

for item in soul{
    print(item)
}

for item in RAndB{
    print(item)
}

for item in HipHop{
    print(item)
}


